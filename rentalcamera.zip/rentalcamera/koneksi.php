<?php
$koneksi = mysqli_connect ('localhost','root','123456','kamera');
// if ($koneksi) {
//     echo "okedesu!";
// } else {
//     echo "dihhh!";
// }
?>