<?php
include "../koneksi.php";
$kd_sewa = $_POST['kd_sewa'];
$kd_camera = $_POST['kd_camera'];
$kd_customer = $_POST['kd_customer'];
$tgl_pinjam = $_POST['tgl_pinjam'];
$tgl_kembali = $_POST['tgl_kembali'];

 $diff=date_diff(date_create($tgl_pinjam),
 date_create($tgl_kembali));
 $hari = $diff->format("%a")+1;

$sql = "SELECT * FROM camera WHERE kd_camera = '$kd_camera'";
$query = mysqli_query($koneksi,$sql);

while ($camera=mysqli_fetch_assoc($query)){
    $tarif_sewa = $camera ['tarif'];
}

$total_sewa = $hari * $tarif_sewa;
echo $total_sewa;

$sql2="UPDATE sewa SET kd_camera='$kd_camera',kd_customer='$kd_customer',
tgl_pinjam='$tgl_pinjam',tgl_kembali='$tgl_kembali',total_sewa='$total_sewa'                                                                                                                                                                                                                        
WHERE kd_sewa='$kd_sewa'";

$query2 = mysqli_query($koneksi,$sql2);

if ($query2) {
    header("location:index.php?update?okedesu!!");
} else {
    header("location:index.php?update?dihhh!!");
}
?>