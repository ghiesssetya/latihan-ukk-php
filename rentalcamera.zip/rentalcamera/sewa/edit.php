<?php
include "../koneksi.php";
$kd_sewa = $_GET['kd_sewa'];
$sql= "SELECT * FROM sewa WHERE kd_sewa='$kd_sewa'";
$query = mysqli_query($koneksi,$sql);
while ($sewa=mysqli_fetch_assoc($query)){
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDIT DATA</title>
</head>
<body>
    <div class="container">
    <h1 align="center">EDIT DATA</h1>
    <form action="proses_edit.php" method="post">
        
        <input type="hidden" name="kd_sewa" value="<?=$sewa['kd_sewa'];?>">
<label for="">KD CAMERA</label>
<input type="number" name="kd_camera" id="" value="<?=$sewa['kd_camera'];?>"><br>

<label for="">KD CUSTOMER</label>
<input type="number" name="kd_customer" id="" value="<?=$sewa['kd_customer'];?>"><br>

<label for="">TANGGAL PINJAM</label>
<input type="date" name="tgl_pinjam" id="" value="<?=$sewa['tgl_pinjam'];?>"><br>

<label for="">TANGGAL KEMBALI</label>
<input type="date" name="tgl_kembali" id="" value="<?=$sewa['tgl_kembali'];?>"><br>

<input type="submit" value="save">
    </form>
    </div>
</body>
</html>
<?php
}
?>