<?php
session_start();
if(!isset($_SESSION['login'])){
    header ("location:login.php?LoginDuluuu");
}
include "../koneksi.php";
$sql = "SELECT * FROM sewa";
$query = mysqli_query($koneksi, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap (2).css">
    <title>SEWA</title>
    <style>
        @media print{
            #cetak{
                display:none;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h1 align="center">RENTAL CAMERA</h1>
    <table class="table">
    <a href="tambah.php" id="cetak"><button class="btn btn-success mx-1">TAMBAH</button></a>
    <button id="cetak" class="btn btn-info mx-1" onclick="window.print()">CETAK</button>
    <a href="../login.php"><button class="btn btn-outline-danger">LOGOUT</button></a><br><br>
    <tr class="table-primary">
        <th scope="row">KD SEWA</th>
        <th scope="row">KD CAMERA</th>
        <th scope="row">KD CUSTOMER</th>
        <th scope="row">TANGGAL PINJAM</th>
        <th scope="row">TANGGAL KEMBALI</th>
        <th scope="row">TOTAL SEWA</th>
        <th scope="row">ACTION</th>
    </tr>
    <?php
    while($sewa=mysqli_fetch_assoc($query)){
    ?>
    <tr>
        <td><?=$sewa['kd_sewa']?></td>
        <td><?=$sewa['kd_camera']?></td>
        <td><?=$sewa['kd_customer']?></td>
        <td><?=$sewa['tgl_pinjam']?></td>
        <td><?=$sewa['tgl_kembali']?></td>
        <td><?=$sewa['total_sewa']?></td>
        <td><a href="hapus.php?kd_sewa=<?=$sewa['kd_sewa']?>"><button class="btn btn-danger">HAPUS</button></a>
        <a href="edit.php?kd_sewa=<?=$sewa['kd_sewa']?>"><button class="btn btn-warning">EDIT</button></a>
    </td>
    </tr>
    <?php
    }
    ?>
    </table>
</div>
</body>
</html>