<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
</head>
<body>
    <div class="container">
    <h1 align="center">LOGIN</h1>
    <form action="proses_login.php" method="post">
        <label for="">Username</label>
        <input type="text" name="username" id=""><br>
        <label for="">Password</label>
        <input type="password" name="password" id=""><br>
        <input type="submit" name="login" id=""><br>
    </form>
    </div>
</body>
</html>